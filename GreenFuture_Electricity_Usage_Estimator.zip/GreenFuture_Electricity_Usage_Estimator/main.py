"""
GreenFuture - Electricity Usage Estimator
A small local Python project for learning how electricity estimates work.

Run with: python main.py
The app stores records in data/usage_records.csv and data/usage_records.json.
"""

from pathlib import Path
from datetime import datetime
import csv
import json

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
REPORT_DIR = ROOT / "reports"
CHART_DIR = ROOT / "charts"
CSV_FILE = DATA_DIR / "usage_records.csv"
JSON_FILE = DATA_DIR / "usage_records.json"

FIELDS = [
    "id", "appliance", "category", "wattage", "hours_per_day",
    "days_per_month", "rate_per_kwh", "energy_kwh", "monthly_cost",
    "created_at"
]


def prepare_folders():
    """Create the folders the app needs before using any files."""
    for folder in (DATA_DIR, REPORT_DIR, CHART_DIR):
        folder.mkdir(exist_ok=True)


def clean_number(prompt, minimum, maximum, allow_zero=False):
    """Keep asking until the user enters a number in the allowed range."""
    while True:
        raw = input(prompt).strip()
        try:
            value = float(raw)
        except ValueError:
            print("Please enter a number, for example 12 or 2.5.")
            continue

        if value < minimum or value > maximum:
            print(f"Enter a value from {minimum} to {maximum}.")
            continue
        if not allow_zero and value == 0:
            print("Zero is not allowed here.")
            continue
        return value


def clean_text(prompt, max_length=50):
    """Read a short, non-empty text value."""
    while True:
        value = input(prompt).strip()
        if not value:
            print("This field cannot be empty.")
        elif len(value) > max_length:
            print(f"Please keep it under {max_length} characters.")
        else:
            return value


def load_records():
    """Load the CSV file; create an empty one if it does not exist."""
    prepare_folders()
    if not CSV_FILE.exists():
        save_records([])
        return []

    records = []
    try:
        with CSV_FILE.open("r", newline="", encoding="utf-8") as file:
            reader = csv.DictReader(file)
            for row in reader:
                try:
                    # Convert stored numbers back to numeric values.
                    for key in ("wattage", "hours_per_day", "days_per_month",
                                "rate_per_kwh", "energy_kwh", "monthly_cost"):
                        row[key] = float(row[key])
                    row["id"] = int(row["id"])
                    records.append(row)
                except (ValueError, TypeError, KeyError):
                    print("Skipped one damaged row in the saved CSV file.")
    except (OSError, csv.Error) as error:
        print(f"Could not read the saved file: {error}")
        print("Starting with an empty list. Your original file is not deleted.")
    return records


def save_records(records):
    """Save the same records in CSV and JSON for easy reuse."""
    prepare_folders()
    with CSV_FILE.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(records)

    with JSON_FILE.open("w", encoding="utf-8") as file:
        json.dump(records, file, indent=4)


def calculate_usage(wattage, hours, days, rate):
    """Return energy in kWh and estimated cost for the selected month."""
    energy = (wattage * hours * days) / 1000
    cost = energy * rate
    return round(energy, 3), round(cost, 2)


def add_record(records):
    print("\n--- Add an appliance ---")
    appliance = clean_text("Appliance name: ")
    category = clean_text("Category (lighting, cooling, kitchen, etc.): ")
    wattage = clean_number("Power in watts (1-20000): ", 1, 20000)
    hours = clean_number("Hours used per day (0.1-24): ", 0.1, 24)
    days = clean_number("Days used in a month (1-31): ", 1, 31)
    rate = clean_number("Electricity rate per kWh (₹): ", 0.01, 100, allow_zero=False)

    energy, cost = calculate_usage(wattage, hours, days, rate)
    next_id = max((int(item["id"]) for item in records), default=0) + 1

    record = {
        "id": next_id,
        "appliance": appliance,
        "category": category,
        "wattage": wattage,
        "hours_per_day": hours,
        "days_per_month": days,
        "rate_per_kwh": rate,
        "energy_kwh": energy,
        "monthly_cost": cost,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
    }
    records.append(record)
    save_records(records)
    print(f"\nSaved! Estimated monthly use: {energy:.2f} kWh")
    print(f"Estimated monthly cost: ₹{cost:.2f}")


def show_records(records):
    print("\n--- Saved appliance records ---")
    if not records:
        print("No records yet. Choose option 1 to add an appliance.")
        return

    print(f"{'ID':<4} {'APPLIANCE':<18} {'CATEGORY':<14} {'kWh/MONTH':>11} {'COST (₹)':>11}")
    print("-" * 64)
    for item in records:
        print(f"{item['id']:<4} {item['appliance'][:17]:<18} "
              f"{item['category'][:13]:<14} {item['energy_kwh']:>11.2f} "
              f"{item['monthly_cost']:>11.2f}")


def search_records(records):
    print("\n--- Find a record ---")
    term = clean_text("Search by appliance or category: ").lower()
    matches = [
        item for item in records
        if term in item["appliance"].lower() or term in item["category"].lower()
    ]
    if not matches:
        print("No matching records found.")
    else:
        show_records(matches)


def show_summary(records):
    print("\n--- Monthly usage summary ---")
    if not records:
        print("Add a few appliances first to see a summary.")
        return

    total_energy = sum(item["energy_kwh"] for item in records)
    total_cost = sum(item["monthly_cost"] for item in records)
    average_cost = total_cost / len(records)
    highest = max(records, key=lambda item: item["monthly_cost"])

    print(f"Appliances recorded : {len(records)}")
    print(f"Estimated energy    : {total_energy:.2f} kWh/month")
    print(f"Estimated cost      : ₹{total_cost:.2f}/month")
    print(f"Average cost/item   : ₹{average_cost:.2f}")
    print(f"Highest cost item   : {highest['appliance']} (₹{highest['monthly_cost']:.2f})")

    if total_energy > 300:
        print("Usage note          : Your estimated total is above 300 kWh/month.")
    else:
        print("Usage note          : Your estimated total is 300 kWh/month or less.")
    print("Note: These are estimates, not a bill from your electricity provider.")


def export_report(records):
    if not records:
        print("There are no records to export yet.")
        return
    prepare_folders()
    total_energy = sum(item["energy_kwh"] for item in records)
    total_cost = sum(item["monthly_cost"] for item in records)
    report = [
        "GREENFUTURE - ELECTRICITY USAGE REPORT",
        f"Created: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "",
        f"Appliances recorded: {len(records)}",
        f"Estimated monthly energy: {total_energy:.2f} kWh",
        f"Estimated monthly cost: Rs. {total_cost:.2f}",
        "",
        "Appliance details",
        "-" * 68,
    ]
    for item in records:
        report.append(
            f"{item['appliance']} | {item['category']} | "
            f"{item['energy_kwh']:.2f} kWh | Rs. {item['monthly_cost']:.2f}"
        )
    report_path = REPORT_DIR / "monthly_summary.txt"
    report_path.write_text("\n".join(report), encoding="utf-8")
    print(f"Report saved to: {report_path.relative_to(ROOT)}")


def make_chart(records):
    if not records:
        print("Add records before creating a chart.")
        return
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("Matplotlib is not installed. Run: pip install matplotlib")
        return

    names = [item["appliance"] for item in records]
    costs = [item["monthly_cost"] for item in records]
    plt.figure(figsize=(10, 5))
    plt.bar(names, costs)
    plt.title("Estimated Monthly Electricity Cost by Appliance")
    plt.xlabel("Appliance")
    plt.ylabel("Estimated cost (₹)")
    plt.xticks(rotation=35, ha="right")
    plt.tight_layout()
    chart_path = CHART_DIR / "monthly_costs.png"
    plt.savefig(chart_path)
    plt.close()
    print(f"Chart saved to: {chart_path.relative_to(ROOT)}")


def import_csv(records):
    """Import rows from another CSV with the basic required columns."""
    path_text = clean_text("CSV file path (example: data/old_records.csv): ", 200)
    path = Path(path_text)
    if not path.is_absolute():
        path = ROOT / path
    required = {"appliance", "category", "wattage", "hours_per_day",
                "days_per_month", "rate_per_kwh"}
    added = 0
    errors = []
    try:
        with path.open("r", newline="", encoding="utf-8-sig") as file:
            reader = csv.DictReader(file)
            if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
                print("CSV needs these columns: " + ", ".join(sorted(required)))
                return
            for line_number, row in enumerate(reader, start=2):
                try:
                    appliance = row["appliance"].strip()
                    category = row["category"].strip()
                    wattage = float(row["wattage"])
                    hours = float(row["hours_per_day"])
                    days = float(row["days_per_month"])
                    rate = float(row["rate_per_kwh"])
                    if not appliance or not category:
                        raise ValueError("appliance and category are required")
                    if not (1 <= wattage <= 20000 and 0.1 <= hours <= 24
                            and 1 <= days <= 31 and 0.01 <= rate <= 100):
                        raise ValueError("a number is outside the accepted range")
                    energy, cost = calculate_usage(wattage, hours, days, rate)
                    new_id = max((int(x["id"]) for x in records), default=0) + 1
                    records.append({
                        "id": new_id, "appliance": appliance, "category": category,
                        "wattage": wattage, "hours_per_day": hours,
                        "days_per_month": days, "rate_per_kwh": rate,
                        "energy_kwh": energy, "monthly_cost": cost,
                        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
                    })
                    added += 1
                except (ValueError, TypeError, KeyError) as error:
                    errors.append(f"Line {line_number}: {error}")
        save_records(records)
        print(f"Imported {added} row(s).")
        if errors:
            log_path = REPORT_DIR / "import_errors.txt"
            log_path.write_text("\n".join(errors), encoding="utf-8")
            print(f"{len(errors)} row(s) were skipped. Details: {log_path.relative_to(ROOT)}")
    except FileNotFoundError:
        print("That file was not found. Check the path and try again.")
    except OSError as error:
        print(f"Could not open the CSV file: {error}")


def print_menu():
    print("\n" + "=" * 48)
    print("          GREENFUTURE | POWER CHECK")
    print("=" * 48)
    print("1. Add an appliance")
    print("2. View all records")
    print("3. Search by name or category")
    print("4. View monthly summary")
    print("5. Create a cost chart")
    print("6. Export a text report")
    print("7. Import records from another CSV")
    print("0. Save and exit")
    print("-" * 48)


def main():
    prepare_folders()
    records = load_records()
    print("Welcome! Let's make everyday electricity use easier to understand.")
    while True:
        print_menu()
        choice = input("Choose an option: ").strip()
        if choice == "1":
            add_record(records)
        elif choice == "2":
            show_records(records)
        elif choice == "3":
            search_records(records)
        elif choice == "4":
            show_summary(records)
        elif choice == "5":
            make_chart(records)
        elif choice == "6":
            export_report(records)
        elif choice == "7":
            import_csv(records)
        elif choice == "0":
            save_records(records)
            print("Your records are saved. See you next time!")
            break
        else:
            print("Please choose one of the listed menu numbers.")


if __name__ == "__main__":
    main()
