# GreenFuture – Electricity Usage Estimator

A beginner-friendly Python project for estimating how much electricity common appliances use and what that usage may cost.

## What it does

- Adds appliances using wattage, hours used per day, days used per month, and electricity rate.
- Calculates estimated monthly energy in kWh and estimated cost in rupees.
- Checks inputs so blank, non-numeric, and out-of-range values do not crash the program.
- Saves records locally in both CSV and JSON formats.
- Searches by appliance name or category.
- Shows a small monthly summary and a high-usage note.
- Exports a text report and, if Matplotlib is installed, a bar chart.
- Imports a CSV file and records row-level errors instead of stopping at the first bad row.

## Requirements

- Python 3.10 or newer
- Matplotlib is optional (only needed for charts)

## Run it

1. Extract the ZIP file.
2. Open the extracted `GreenFuture_Electricity_Usage_Estimator` folder in VS Code or a terminal.
3. Open a terminal in that folder.
4. Run:

   ```bash
   python main.py
   ```

5. Choose an option from the menu.

For charts, install Matplotlib once:

```bash
python -m pip install -r requirements.txt
```

If you do not install Matplotlib, the rest of the program still works.

## Calculation used

- Monthly energy (kWh) = `(wattage × hours per day × days per month) ÷ 1000`
- Monthly estimated cost = `monthly energy × rate per kWh`

Example: a 100 W fan used 8 hours per day for 30 days at ₹8 per kWh:

- Energy = `(100 × 8 × 30) ÷ 1000 = 24 kWh`
- Estimated cost = `24 × 8 = ₹192`

## Project structure

```text
GreenFuture_Electricity_Usage_Estimator/
│
├── main.py
├── README.md
├── requirements.txt
├── data/
│   ├── usage_records.csv
│   └── usage_records.json
├── reports/
│   └── (reports are created here)
└── charts/
    └── (charts are created here)
```

## Try these demo steps

1. Choose `1` and add an appliance.
2. For wattage, try typing `hello` first. The program should ask again.
3. Enter realistic values and save the record.
4. Choose `2` to see the saved list.
5. Choose `4` to see the summary.
6. Choose `5` to create a chart (after installing Matplotlib).
7. Exit with `0`, reopen the program, and confirm that your records are still there.

## Importing another CSV

The input CSV must contain these column names:

```csv
appliance,category,wattage,hours_per_day,days_per_month,rate_per_kwh
Ceiling Fan,cooling,75,8,30,8
LED Bulb,lighting,9,6,30,8
```

Use option `7` and enter the path to the CSV file. Invalid rows are skipped and listed in `reports/import_errors.txt`.

## Notes for your presentation

Explain it in your own words:

> "My project helps people get a simple estimate of their electricity use. We enter an appliance's power, how many hours we use it, the number of days, and the electricity rate. Python calculates units and the estimated cost. The records are saved on the computer, so they are available next time too."

Mention that the estimate depends on the rate entered by the user. Actual electricity bills can also include fixed charges, taxes, slabs, and other adjustments. This is a learning project, not an official bill calculator.

## Make it your own

Before presenting, add a few appliances you actually see at home or in your classroom, change the welcome message, and explain the calculation yourself. Do not claim that the program predicts an exact electricity bill.
